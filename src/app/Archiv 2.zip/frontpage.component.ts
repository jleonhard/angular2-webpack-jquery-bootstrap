/**
 * Created by johannes.leonhard on 31.08.17.
 */
import { Component } from '@angular/core';

@Component({
  selector: 'app-frontpage',
  template: `
  <app-project-diamonds></app-project-diamonds>
  `
})
export class FrontpageComponent {
}
