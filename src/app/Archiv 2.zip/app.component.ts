/**
 * Created by johannes.leonhard on 30.08.17.
 */
import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `
    <h1>{{title}}</h1>
    <nav>
     <a routerLink="/home" routerLinkActive="active">Home</a>
     <a routerLink="/projects" routerLinkActive="active">all Projects</a>
    </nav>
    <router-outlet></router-outlet>
  `
})
export class AppComponent {
  title = 'Portfolio';
}
