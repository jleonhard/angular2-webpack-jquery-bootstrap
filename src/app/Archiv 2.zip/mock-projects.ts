/**
 * Created by johannes.leonhard on 30.08.17.
 */
import { Project } from './project';

export const PROJECTS: Project[] = [
  { id: 1, name: 'Skoda Superb Kampagne' },
  { id: 2, name: 'Skoda Fahrassistenzsysteme' },
  { id: 3, name: 'Umweltarena Solarrechner' },
  { id: 4, name: 'Samsung Hide&Seek' },
  { id: 5, name: 'SLF Whiterisk' },
  { id: 6, name: 'Raumgleiter App' }
];
