import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { Project } from './project';
import { ProjectService } from './project.service';

@Component({
  selector: 'app-projects',
  template: `
    <h1>{{title}}</h1>
    <ul class="projects">
      <li *ngFor="let project of projects"
        [class.selected]="project === selectedProject"
        (click)="onSelect(project)">
        <span class="badge">{{project.id}}</span> {{project.name}}
      </li>
    </ul>
  `,
  styleUrls: [ './projects.component.css' ],
  providers: [ProjectService]
})

export class ProjectsComponent implements OnInit {
  title = 'Projects';
  projects: Project[];
  selectedProject: Project;

  constructor(
    private projectService: ProjectService,
    private router: Router) { }

  getProjects(): void {
    this.projectService.getProjects().then(projects => this.projects = projects);
  }
  ngOnInit(): void {
    this.getProjects();
  }
  onSelect(project: Project): void {
    this.selectedProject = project;
    this.gotoDetail();
  }
  gotoDetail(): void {
    this.router.navigate(['/detail', this.selectedProject.id]);
  }
}