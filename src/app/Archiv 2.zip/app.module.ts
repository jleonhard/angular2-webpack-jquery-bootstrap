import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms'; // <-- NgModel lives here
import { HttpModule } from '@angular/http';

import { AppComponent } from './app.component';
import { ProjectDetailComponent } from './project-detail.component';
import { ProjectsComponent } from './projects.component';
import { FrontpageComponent } from './frontpage.component';
import { ProjectDiamondsComponent } from './project-diamonds.component';
import { ProjectService } from './project.service';

import { AppRoutingModule } from './app-routing.module';

// Imports for loading & configuring the in-memory web api
import { InMemoryWebApiModule } from 'angular-in-memory-web-api';
import { InMemoryDataService } from './in-memory-data.service';

@NgModule({
  imports: [
    BrowserModule,
    FormsModule, // <-- import the FormsModule before binding with [(ngModel)]
    HttpModule,
    InMemoryWebApiModule.forRoot(InMemoryDataService),
    AppRoutingModule
  ],
  declarations: [
    AppComponent,
    ProjectsComponent,
    FrontpageComponent,
    ProjectDetailComponent,
    ProjectDiamondsComponent
  ],
  providers: [ProjectService],
  bootstrap: [ AppComponent ]
})
export class AppModule {
}
