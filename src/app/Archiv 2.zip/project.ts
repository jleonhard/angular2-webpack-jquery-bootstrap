/**
 * Created by johannes.leonhard on 29.08.17.
 */
export class Project {
  id: number;
  name: string;
}
