export { DetailModule } from './detail.module';
